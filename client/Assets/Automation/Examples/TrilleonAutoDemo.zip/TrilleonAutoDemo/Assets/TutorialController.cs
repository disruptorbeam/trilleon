﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TutorialController : MonoBehaviour {

	public static TutorialController Self { get; private set; }

	public static bool TutorialStart { get; set; }
	public static bool IsTutorial { get; set; }
	public static int TutorialStep { get; set; }
	public static bool NextTutorialStep { get; set; }
	public static bool IntroDone { get; set; }

	void Start () {

		Self = this;
		GameController.IsTutorial = true;

	}

	void Update () {

		if(TutorialStart && IsTutorial) {

			if(NextTutorialStep) {

				StartCoroutine(TutorialNext());

			}

		}

	}

	void TutorialOver() {

		TutorialStart = false;
		GameController.IsTutorial = false;
		StartCoroutine(GameController.Self.GetComponent<GameController>().GameOver());

	}

	public void TutorialActivate() {

		TutorialStart = true;
		GameController.Self.ScoreText.gameObject.SetActive(true);
		GameController.Self.LevelText.gameObject.SetActive(true);
		GameController.Self.LevelText.text = "Level 1";
		GameController.Self.Calculator.gameObject.SetActive(true);
		GameController.Self.MainMenu.gameObject.SetActive(false);

	}

	public IEnumerator ReadySteadyGo() {

		int alpha = 255;
		GameController.Self.GetReady.text = "Ready";
		while(alpha > 0) {

			alpha -= 5;
			GameController.Self.GetReady.color = (Color)new Color32((byte)255, (byte)255, (byte)255, (byte)alpha);
			yield return new WaitForEndOfFrame();

		}
		alpha = 255;
		GameController.Self.GetReady.text = "Steady";
		Canvas.ForceUpdateCanvases();
		while(alpha > 0) {

			alpha -= 5;
			GameController.Self.GetReady.color = (Color)new Color32((byte)255, (byte)255, (byte)255, (byte)alpha);
			yield return new WaitForEndOfFrame();

		}
		alpha = 255;
		int rand = TrilleonAutomation.Q.help.RandomIndex(10);
		if(rand > 5) {

			GameController.Self.GetReady.text = "Quack!";

		} else {

			GameController.Self.GetReady.text = "Go!";

		}
		Canvas.ForceUpdateCanvases();
		while(alpha > 0) {

			alpha -= 5;
			GameController.Self.GetReady.color = (Color)new Color32((byte)255, (byte)255, (byte)255, (byte)alpha);
			yield return new WaitForEndOfFrame();

		}
		GameController.Self.GetReady.gameObject.SetActive(false);
		GameController.Self.ScoreText.gameObject.SetActive(true);
		yield return null;

	}

	IEnumerator TutorialNext() {

		switch(TutorialStep) {
			case 0:

				break;
			case 1:

				break;
			case 2:

				break;
			case 3:

				break;
			case 4:

				break;
			case 5:
				TutorialOver();
				break;
		}
		NextTutorialStep = false;
		yield return null;

	}

}