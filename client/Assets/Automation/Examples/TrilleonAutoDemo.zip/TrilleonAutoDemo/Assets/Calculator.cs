﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TrilleonAutomation;

public class Calculator : MonoBehaviour {

	public static string CurrentAnswer { get; private set; }

	void Start() {

		CurrentAnswer = string.Empty;

	}

	public static void ButtonClick(string button) {
		
		int val = 0;
		if(int.TryParse(button, out val)) {

			CurrentAnswer += button;

		} else {

			switch(button) {
				case "PN":
					CurrentAnswer = CurrentAnswer.Length > 0 ? CurrentAnswer.Substring(0, 1) != "-" ? string.Format("-{0}", CurrentAnswer) : string.Format("{0}", CurrentAnswer.Substring(1, CurrentAnswer.Length - 1)) : "-";
					break;
				case "D":
					if(!CurrentAnswer.Contains(".")) {
						
						CurrentAnswer += ".";

					}
					break;
				case "C":
					CurrentAnswer = string.Empty;
					break;
				case "E":
					List<Equation> matches = GameController.Self.ActiveEquations.FindAll(x => x.CorrectAnswer == CurrentAnswer && (x.GetComponent<RectTransform>().localPosition.x < Screen.height / 2 || x.GetComponent<RectTransform>().localPosition.x > Screen.height / -2));
					if(matches.Any()) {
							
						for(int x = 0; x < matches.Count; x++) {

							GameController.UpdateScore(true, matches[x].GetComponent<Equation>().IsDuck);
							GameController.Self.ActiveEquations.Remove(matches[x]);
							Destroy(matches[x].gameObject);

						}

					}
						
					CurrentAnswer = string.Empty;
					break;
			}

		}
		GameController.Self.CalculatorValueText.text = CurrentAnswer;

	}

}