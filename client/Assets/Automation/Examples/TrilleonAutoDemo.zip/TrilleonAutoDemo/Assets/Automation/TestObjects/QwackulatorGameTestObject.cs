﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace TrilleonAutomation {

	public class QwackulatorGameTestObject : MonoBehaviour {

		public static QwackulatorGameTestObject steps {
			get {
				QwackulatorGameTestObject self = AutomationMaster.StaticSelf.GetComponent<QwackulatorGameTestObject>();
				if(self == null) {
					return AutomationMaster.StaticSelf.AddComponent<QwackulatorGameTestObject>();
				}
				return self;
			}
		}

		public static GameController primary {
			get {
				return GameController.Self;
			}
		}

		public static Button button_startGame {
			get {
				return primary.NewGame;
			}
		}

		public static int int_score {
			get {
				return primary.ScoreText.text.Replace("Score:", string.Empty).ToInt();
			}
		}

		public static List<Equation> objs_activeEquations {
			get {
				return primary.ActiveEquations;
			}
		}

	}

}