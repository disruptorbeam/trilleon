﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace TrilleonAutomation {

	[AutomationClass]
	[DebugClass]
	public class ConditionalDeferrmentTests : MonoBehaviour {

		static bool RequiredDummyValueIsSet = false;

		[SetUpClass]
		public IEnumerator SetUpClass() {

			Q.AddConditionalDeferrment(new ConditionalDeferrment(this.ConditionalDeferrment_DeferredUntilRequiredValueIsSet(), () => RequiredDummyValueIsSet, 1));
			yield return null;

		}

		[Automation("Debug/Dependencies")]
		[Automation("Trilleon/Validation")]
		[Validate(Expect.Success)]
		public IEnumerator ConditionalDeferrment_DeferredUntilRequiredValueIsSet() {

			yield return StartCoroutine(Q.assert.IsTrue(RequiredDummyValueIsSet && AutomationMaster.TestRunContext.CompletedTests.Contains("ConditionalDeferrment_SetRequiredValue"), "Required condition is set correctly. ConditionalDeferrment_SetRequiredValue ran first because this test was deferred."));

		}

		[Automation("Debug/Dependencies")]
		[Automation("Trilleon/Validation")]
		[Validate(Expect.Success)]
		public IEnumerator ConditionalDeferrment_SetRequiredValue() {

			RequiredDummyValueIsSet = true;
			yield return StartCoroutine(Q.assert.Pass("Setting RequiredDummyValueIsSet to true. This test should run before ConditionalDeferrment_DeferredUntilRequiredValueIsSet() because of the ConditionalDeferrment supplied in SetUpClass."));

		}

	}

}