﻿using System;
using PubNubMessaging.Core;
using NUnit.Framework;
using UnityEngine;

namespace PubNubMessaging.Tests
{
    [TestFixture]
    public class PubnubUnityUnitTests
    {
        #if DEBUG
        //GetLocalUserState
        //BuildJsonUserState
        //BuildJsonUserState
        //DeleteLocalUserState
        //AddOrUpdateOrDeleteLocalUserState


        #endif
    }
}

