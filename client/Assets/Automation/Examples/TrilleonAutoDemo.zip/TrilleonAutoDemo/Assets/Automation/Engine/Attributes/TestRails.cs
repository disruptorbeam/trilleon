﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;

namespace TrilleonAutomation {

	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Class, AllowMultiple = false)]
	public class TestRails : Attribute {

		public int RunId { get; private set; }

		public TestRails(int RunId) {

			this.RunId = RunId;

		}

	}

}