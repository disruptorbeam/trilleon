﻿using System;

namespace TrilleonAutomation {

   [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
	public class DebugClass : Attribute { }

}