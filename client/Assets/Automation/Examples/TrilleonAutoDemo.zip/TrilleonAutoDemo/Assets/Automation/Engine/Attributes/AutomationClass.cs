﻿using System;
using UnityEngine;

namespace TrilleonAutomation {
   
   [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
   public class AutomationClass : Attribute {}

}