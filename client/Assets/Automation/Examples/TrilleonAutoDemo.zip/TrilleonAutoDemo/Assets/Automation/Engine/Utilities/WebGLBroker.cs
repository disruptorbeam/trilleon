﻿#if UNITY_WEBGL || UNITY_EDITOR
using System;
using System.Runtime.InteropServices;
using UnityEngine;

namespace TrilleonAutomation {

	/// <summary>
	/// Brokers communication between Trilleon logic and the browser that contains a WebGL canvas game. 
	/// This is an alternative way to communicate with a server running a WebGL test run, as opposed to using Pubsub services.
	/// </summary>
	public class WebGLBroker : MonoBehaviour {

		//Outgoing call to browser (Points to Engine > Xtra > Plugin javascript file and functions).
		[DllImport("__Internal")]
		public static extern void ReportXmlResults(string xml);
		[DllImport("__Internal")]
		public static extern void ReportJsonResults(string json);

		//Incoming call from browser (Sent by "SendMessage()" Unity javascript method that points to this class and method).
		public void LaunchTest(string test) {

			AutomationMaster.Arbiter.ReceiveMessage(string.Format("{{ \"automation_command\": \"rt *{0}\" }}", test), true);

		}

	}

}
#endif