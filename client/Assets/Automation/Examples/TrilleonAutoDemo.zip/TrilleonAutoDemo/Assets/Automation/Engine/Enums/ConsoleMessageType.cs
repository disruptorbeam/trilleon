﻿namespace TrilleonAutomation {

   public enum ConsoleMessageType {
   
      AssertionFail,
      AssertionPass,
      AssertionIgnore,
      AssertionSkip,
      FileSaved,
      TestRunnerUpdate,
      UnityConsoleCommandSent,
      Pubsub

   }
}