﻿namespace TrilleonAutomation {
   
   public enum DependencyNodeConnectionType {

      Incoming,
      Outgoing

   }

}