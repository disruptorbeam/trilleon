﻿public enum Expect {
	Failure,
	Success,
	Ignored,
	Skipped,
	OrderRan,
	RanBefore,
	RanAfter
}