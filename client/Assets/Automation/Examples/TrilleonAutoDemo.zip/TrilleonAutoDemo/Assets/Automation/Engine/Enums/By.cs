﻿namespace TrilleonAutomation {

   public enum By {

      Default,
      TagName,
      TextContent,
      ImageFileName,
      GameObjectType,
      ContainsComponent, //TODO: REMOVE WHEN ALL REFERENCES UPDATED.
      Hierarchy,
      Name

   }

}