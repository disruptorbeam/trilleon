﻿using System;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace TrilleonAutomation {

	[AutomationClass]
	public class CalculatorTutorialTests : MonoBehaviour {

		[SetUpClass]
		public IEnumerator SetUpClass() {

			yield return null;

		}

		[SetUp]
		public IEnumerator SetUp() {

			yield return null;

		}

		[Automation("Calculator")]
		[Ignore("Incomplete")]
		public IEnumerator TutorialExampleEquationRegeneratedIfFirstNotAnswered() {

			yield return null;

		}

		[Automation("Calculator")]
		[Ignore("Incomplete")]
		public IEnumerator TutorialExampleEquationCanBeAnswered() {

			yield return null;

		}

		[Automation("Calculator")]
		[Ignore("Incomplete")]
		public IEnumerator TutorialExampleDuckRegeneratedIfFirstNotSolved() {

			yield return null;

		}

		[Automation("Calculator")]
		[Ignore("Incomplete")]
		public IEnumerator TutorialExampleDuckCanBeSolved() {

			yield return null;

		}

		[Automation("Calculator")]
		[Ignore("Incomplete")]
		public IEnumerator TutorialReturnsToMainMenuObCompletion() {

			yield return null;

		}

		[TearDown]
		public IEnumerator TearDown() {

			//Reset Calculator value.
			yield return StartCoroutine(Q.driver.Try.Click(CalculatorTestObject.GetButton("C"), timeout: 2f));

		}

		[TearDownClass]
		public IEnumerator TearDownClass() {

			yield return null;

		}

	}

}