﻿namespace TrilleonAutomation {

   public enum FailType {
      Class,
      Test
   }

}