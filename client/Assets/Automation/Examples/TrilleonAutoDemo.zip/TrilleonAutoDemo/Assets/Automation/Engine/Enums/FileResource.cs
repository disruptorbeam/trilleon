﻿public enum FileResource {

	ExtendableResource,
	LaunchInstructions,
	BuddyHistory,
	NexusTabs,
	ManifestGUISettings,
	LatestTestResults,
	LatestTestResultsMeta,
	Favorites,
	TrilleonConfig,
	ReportCss,
	ReportJavascript

}