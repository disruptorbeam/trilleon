﻿using System;
using UnityEngine;

namespace TrilleonAutomation {

	[AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
	public class UnityTestClass : Attribute {}

}