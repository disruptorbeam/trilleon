﻿namespace TrilleonAutomation {

   public enum Condition {

      Default,
      //AreEqual,
      TextContains,
      IsActiveVisibleAndInteractable,
      IsTrue,
      Exists,
      Any

   }

}