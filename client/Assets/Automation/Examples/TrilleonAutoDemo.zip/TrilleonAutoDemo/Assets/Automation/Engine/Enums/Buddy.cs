﻿public enum Buddy {
   Action,
   Reaction,
   CounterReaction
}