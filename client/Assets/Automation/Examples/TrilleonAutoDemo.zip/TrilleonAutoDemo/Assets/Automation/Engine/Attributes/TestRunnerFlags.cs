﻿using System;
using System.Collections.Generic;

namespace TrilleonAutomation {

	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Class, AllowMultiple = false)]
	public class TestRunnerFlags : Attribute {

		public List<TestFlag> Flags { 
			get { 
				return flags;
			}
		}
		List<TestFlag> flags = new List<TestFlag>();

		/// <summary>
		/// Adds special flags to an Automation test that cause important behavioral changes in the test runner (AutomationMaster).
		/// </summary>
		/// <param name="testCategoryName"> TestFlag to add. </param>
		public TestRunnerFlags(params TestFlag[] Flags) {

			this.flags.AddRange(Flags.ToList());

		}

	}
}