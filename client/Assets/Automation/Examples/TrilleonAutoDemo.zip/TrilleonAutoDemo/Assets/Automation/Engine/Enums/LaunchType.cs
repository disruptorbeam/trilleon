﻿namespace TrilleonAutomation {

	public enum LaunchType {

		MethodName,
		MultipleMethodNames,
		CategoryName,
		MultipleCategoryNames,
		Mix,
		All

	}

}