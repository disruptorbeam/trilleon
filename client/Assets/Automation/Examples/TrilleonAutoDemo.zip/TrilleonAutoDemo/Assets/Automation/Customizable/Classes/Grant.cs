﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace TrilleonAutomation {

   public class Grant {

      /*
         WAIT! Changes to field names and types must also be made in the SetUpCommand constants 
         and GrantPlayer method as field names are strings and not references.
      */

      public int Gold;
      public int Silver;

   }

}