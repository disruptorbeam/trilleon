﻿using System;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace TrilleonAutomation {

	[AutomationClass]
	public class CalculatorTutorialTests : MonoBehaviour {

		[SetUpClass]
		public IEnumerator SetUpClass() {

			yield return null;

		}

		[SetUp]
		public IEnumerator SetUp() {

			yield return null;

		}

		[Automation("Tutorial")]
		[DependencyTest(1)]
		public IEnumerator TutorialCanBeInitializedFromMainMenu() {

			yield return StartCoroutine(Q.driver.Click(QwackulatorGameTestObject.button_startTutorial, "Select Tutorial button."));
			yield return StartCoroutine(Q.driver.WaitFor(() => Q.driver.IsActiveVisibleAndInteractable(QwackulatorGameTestObject.gui_tutorialText.gameObject), "Tutorial text sequence begins."));

		}

		[Automation("Tutorial")]
		public IEnumerator TutorialExampleEquationRegeneratedIfFirstNotAnswered() {

			yield return StartCoroutine(Q.driver.WaitFor(() => QwackulatorGameTestObject.equation_tutorial != null, "Tutorial text sequence begins that describes game concepts and regular equations.", 30f));
			int currentEquation = QwackulatorGameTestObject.equation_tutorial.Id;
			yield return StartCoroutine(Q.assert.IsTrue(!QwackulatorGameTestObject.equation_tutorial.IsDuck, "Equation should not be a Duck."));
			yield return StartCoroutine(Q.driver.WaitFor(() => QwackulatorGameTestObject.equation_tutorial != null && currentEquation != QwackulatorGameTestObject.equation_tutorial.Id, "If the tutorial eqaution is not answered in time, it is destroyed, and a new one appears for the user.", 45f));

		}

		[Automation("Tutorial")]
		public IEnumerator TutorialExampleEquationCanBeAnswered() {

			yield return StartCoroutine(Q.driver.WaitFor(() => QwackulatorGameTestObject.equation_tutorial != null, "Equation exists."));
			yield return StartCoroutine(CalculatorTestObject.steps.AnswerEquation(QwackulatorGameTestObject.equation_tutorial));

		}

		[Automation("Tutorial")]
		public IEnumerator TutorialExampleDuckRegeneratedIfFirstNotSolved() {

			yield return StartCoroutine(Q.driver.WaitFor(() => QwackulatorGameTestObject.duck_tutorial != null, "Tutorial text sequence begins that describes Ducks.", 45f));
			int currentEquation = QwackulatorGameTestObject.duck_tutorial.Id;
			yield return StartCoroutine(Q.assert.IsTrue(QwackulatorGameTestObject.duck_tutorial.IsDuck, "Equation should be a Duck."));
			yield return StartCoroutine(Q.driver.WaitFor(() => QwackulatorGameTestObject.duck_tutorial != null && currentEquation != QwackulatorGameTestObject.duck_tutorial.Id, "If the tutorial eqaution is not answered in time, it is destroyed, and a new one appears for the user.", 45f));

		}

		[Automation("Tutorial")]
		public IEnumerator TutorialExampleDuckCanBeSolved() {

			yield return StartCoroutine(Q.driver.WaitFor(() => QwackulatorGameTestObject.duck_tutorial != null, "Duck equation exists.", 45f));
			yield return StartCoroutine(CalculatorTestObject.steps.AnswerEquation(QwackulatorGameTestObject.duck_tutorial));

		}

		[Automation("Tutorial")]
		public IEnumerator TutorialReturnsToMainMenuObCompletion() {

			yield return StartCoroutine(Q.driver.WaitFor(() => Q.driver.IsActiveVisibleAndInteractable(GameController.Self.MainMenu), "Main menu re-appears after tutorial completion.", 25f));

		}

		[TearDown]
		public IEnumerator TearDown() {

			yield return null;

		}

		[TearDownClass]
		public IEnumerator TearDownClass() {

			yield return null;

		}

	}

}