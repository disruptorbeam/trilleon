﻿using UnityEngine;
using UnityEditor;
using System;
using System.Reflection;
using System.IO;
using UnityEditor.Callbacks;

namespace TrilleonAutomation {

	[InitializeOnLoad]
	public class TestingStuff {

        static TestingStuff()
		{
			GUI.color = Color.blue;
            GUI.backgroundColor = Color.blue;
		}

	}
	/// <summary>
	/// Open a webview within Unity editor. (similar as AssetStore window)
	/// </summary>
	public class TestWindow : EditorWindow {

		[PostProcessBuildAttribute(1)]
		public static void OnPostprocessBuild(BuildTarget target, string pathToBuiltProject) {
			Debug.Log( pathToBuiltProject );
		}

		static string Url { get; set; }
		//static object window;
		static BindingFlags Flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.SetField | BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.FlattenHierarchy;
		static Type webView;
		static Assembly editorAssembly = typeof(Editor).Assembly;
		static EditorWindow win;

		[MenuItem("Trilleon/Web")]
		static void Open() {

			Url = string.Format("file://{0}", Directory.GetFiles(FileBroker.REPORTS_DIRECTORY, "report.html", SearchOption.AllDirectories).ToList().First());
			webView = editorAssembly.GetType("UnityEditor.Web.WebViewEditorWindowTabs");
			var methodInfo = webView.GetMethod("Create", Flags);
			methodInfo = methodInfo.MakeGenericMethod(webView);
			methodInfo.Invoke(null, new object[] { "Trilleon", Url, 9999, 9999, 9999, 9999 });

			/*
			var rawWin = (EditorWindow)typeof(EditorWindow)
				.GetMethod("GetWindow", new Type[] { typeof(string), typeof(bool), typeof(System.Type[]) })
				.MakeGenericMethod(webView)
				.Invoke(null, new object[] { "Test", true, new Type[] { typeof(SceneView), editorAssembly.GetType("UnityEditor.GameView"), editorAssembly.GetType("UnityEditor.InspectorWindow") }});

			FieldInfo finfo = null;
			PropertyInfo pinfo = null;

			Type guiViewType = editorAssembly.GetType("UnityEditor.GUIView");
			pinfo = guiViewType.GetProperty("current", Flags);
			var guiView = pinfo.GetValue(null, new object[] { });

			Type contWinType = editorAssembly.GetType("UnityEditor.ContainerWindow");
			FieldInfo finfo = contWinType.GetField("s_AllWindows", Flags);
			object all_windows = finfo.GetValue(null);
			object wind = null;
			foreach(object window in aÍll_windows as IList) {

				wind = window;
				break;

			}

			guiViewType.GetMethod("SetWindow", new Type[] { })
				.Invoke(null, new object[] { wind });


			Type webViewActual = editorAssembly.GetType("UnityEditor.WebView");
			var rawWebView = typeof(ScriptableObject)
				.GetMethod("CreateInstance", new Type[] { })
				.MakeGenericMethod(webViewActual)
				.Invoke(null, new object[] { });
			//webViewActual.GetMethod("InitWebView", Flags)
				//.Invoke(rawWebView, new object[] { guiView, 0, 0, 9999, 9999, false });
			//finfo = webViewActual.BaseType.GetField("hideFlags", Flags);
			//finfo.SetValue(rawWin, HideFlags.HideAndDontSave);
			
			pinfo = webView.BaseType.GetProperty("webView", Flags);
			pinfo.SetValue(rawWin, rawWebView, new object[] { });

			finfo = webView.BaseType.GetField("m_InitialOpenURL", Flags);
			finfo.SetValue(rawWin, Url);

			webView.GetMethod("LoadURL", Flags)
				.Invoke(rawWebView, new object[] { Url });
			
			webView.GetMethod("InitWebView", Flags)
				.Invoke(rawWin, new object[] { new Rect(0, 0, 999, 999) });
			*/

		}

    }

}