﻿using UnityEngine;
using System;
using UnityEngine.UI;
using UnityEngine.EventSystems;

namespace TrilleonAutomation {

	/// <summary>
	/// Simple wrapper class that allows you to seemlessly switch between using your own command/cheat console to invoke cheats, or you can use the native Trilleon CommandConsole (default).
	/// </summary>
	public static class CommandConsoleBroker  {

		//Use custom extended command console. Replace `ConsoleCommands` type with yours.
		public static ConsoleCommands Extended { 
			get {
				//TODO: Your code here! Remove all but boolean if invoked by static method. Else, use this for instance.
				if(_extended == null) {
					_extended = null;
				}
				extend = true;
				return _extended;
			}
		}
		private static ConsoleCommands _extended;

		//All commands that read CommandConsoleBroker.Extend.SendCommand will use extended logic, while invoking by CommandConsoleBroker.SendCommand will use the native Trilleon logic.
		private static bool extend = false; 

		/// <summary>
		/// Take provided command string and delegate it to the requested command console logic.
		/// </summary>
		public static void SendCommand(string fullRawCommand) {

			if (extend) {

				//TODO: Add your custome code to send this command directly/programmatically to your command console's processor logic.

			} else {

				ConsoleCommands.SendCommand(fullRawCommand);

			}

			extend = false; //Return to false. 

		}

	}

}