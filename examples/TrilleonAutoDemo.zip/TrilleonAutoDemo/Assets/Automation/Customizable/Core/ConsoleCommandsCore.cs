﻿using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Reflection;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using MiniJSON;

namespace TrilleonAutomation {

	//All game-agnostic cheat/commands go here. These are cheats that should be available across all games within the company.
	public abstract class ConsoleCommandsCore : ConsoleCommandsBase {

		/// <summary>
		/// Add all valid commands with accompanying logic to launch in region below. Command aliases cannot contains spaces.
		/// </summary>
		protected void ImplementCore() {

			//TODO: Your company-specific commands here.
			ImplementBase(); //Required to add Base framework commands.

		}

		//Your Commands Here!
		#region Console Command delegates

		#endregion

		#region Console Command support methods

		#endregion

	}

}