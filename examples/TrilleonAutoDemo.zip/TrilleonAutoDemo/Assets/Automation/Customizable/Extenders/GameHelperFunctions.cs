﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

namespace TrilleonAutomation {

   public class GameHelperFunctions : HelperFunctions {

		//TODO: Your helper functions here1

	}

}