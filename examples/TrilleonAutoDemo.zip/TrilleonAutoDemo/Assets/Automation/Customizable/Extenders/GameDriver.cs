﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace TrilleonAutomation {

   /// <summary>
   /// Put game-specific driver code here!
   /// </summary>
   public class GameDriver : Driver {

/* TODO: EXTEND CODE?!

		public IEnumerator SendKeys(MyCustomInputField field, string keysToSend){

			PreCommandCheck(true);
			//My Custom Code
			PostCommandCheck(true);

		}
		
		public IEnumerator Click(GameObject obj, string optionalFailMessage = ""){

			PreCommandCheck(true);
			//My Custom Code
			PostCommandCheck(true);

		}
		
*/

   }

}