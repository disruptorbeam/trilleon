Copyright DisruptorBeam, Inc. 2016, 2017, 2018
The Trilleon framework, its code and assets, along with all content except for what appears under the "ThirdParty" folder 
were created by Tim Sibiski for the Unity game engine. This framework is free and open source. Content may be distributed 
and modified freely (and redistributed as modified) as long as credit for the framework is always attributed to creator 
and copyright owner. 